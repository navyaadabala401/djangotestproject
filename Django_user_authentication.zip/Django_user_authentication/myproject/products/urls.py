# products/urls.py
from django.urls import path

from .views import SignUpView
from . import products


urlpatterns = [
    path('signup/', SignUpView.as_view(), name='signup'),
    path('userproducts/<int:user_id>', products.viewUserProducts, name='userproducts'),
]