from django.db import models

# Create your models here.


# hios_tpa_master
class Products(models.Model):
    id = models.BigAutoField(primary_key=True)
    product_name = models.CharField(max_length=300, blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    isactive = models.IntegerField(blank=True, null=True)
    created = models.DateTimeField(blank=True, null=True)
    modified = models.DateTimeField(blank=True, null=True)
    # # created_by = models.ForeignKey(HiosUsers, null=True, on_delete=models.SET_NULL, related_name='created_by_name',
    # #                                db_column='created_by')
    # # modified_by = models.ForeignKey(HiosUsers, null=True, on_delete=models.SET_NULL, related_name='modified_by_name',
    #                                 db_column='modified_by')
    created_by = models.BigIntegerField(blank=True, null=True)
    modified_by = models.BigIntegerField(blank=True, null=True)

    class Meta:
        # managed = True
        db_table = 'user_products'
