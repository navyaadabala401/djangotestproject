from .models import Products
from django.shortcuts import redirect
from django.shortcuts import render

def viewUserProducts(request,user_id):

    products = Products.objects.filter(isactive=1,user_id =user_id).values('product_name')
    return render(request, 'userproducts.html',{'products': products})
